const recordBtn = document.createElement("button");
recordBtn.textContent = "🎙️ Speak";
recordBtn.onclick = startRecording;
document.getElementById("chat-form").appendChild(recordBtn);

let mediaRecorder, audioChunks = [];

async function startRecording() {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    mediaRecorder = new MediaRecorder(stream);
    audioChunks = [];

    mediaRecorder.ondataavailable = e => audioChunks.push(e.data);
    mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunks, { type: "audio/webm" });
        const formData = new FormData();
        formData.append("audio", audioBlob, "speech.webm");

        const response = await fetch("/transcribe", {
            method: "POST",
            body: formData
        });

        const data = await response.json();
        document.querySelector("input[name='message']").value = data.text;
    };

    mediaRecorder.start();
    setTimeout(() => mediaRecorder.stop(), 4000); // record for 4 seconds
}