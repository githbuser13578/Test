from flask import Flask, render_template, request, jsonify
import openai
import os
from werkzeug.utils import secure_filename

openai.api_key = os.getenv("OPENAI_API_KEY")

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'

conversation = []

@app.route("/", methods=["GET", "POST"])

def chat():
    
    if "username" not in session:
        return redirect("/login")

    username = session["username"]
    if "convos" not in session:
        session["convos"] = {}
    if username not in session["convos"]:
        session["convos"][username] = []
    conversation = session["convos"][username]
    

    if request.method == "POST":
        user_input = request.form["message"]
        personality = request.form.get("personality", "You are a helpful assistant.")

        # Reset system message each time based on selected personality
        conversation = [{"role": "system", "content": personality}]
        conversation.append({"role": "user", "content": user_input})

        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=conversation
        )

        ai_reply = response["choices"][0]["message"]["content"]
        conversation.append({"role": "assistant", "content": ai_reply})
    
    
    if "username" not in session:
        return redirect("/login")

    username = session["username"]
    if "convos" not in session:
        session["convos"] = {}
    if username not in session["convos"]:
        session["convos"][username] = []
    conversation = session["convos"][username]
    

    if request.method == "POST":
        user_input = request.form["message"]
        conversation.append({"role": "user", "content": user_input})

        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=conversation
        )

        ai_reply = response["choices"][0]["message"]["content"]
        conversation.append({"role": "assistant", "content": ai_reply})

    visible_convo = [msg for msg in conversation if msg["role"] != "system"]
    return render_template("chat.html", conversation=visible_convo)

@app.route("/conversations")
def view_conversations():
    visible_convo = [msg for msg in conversation if msg["role"] != "system"]
    return render_template("conversations.html", conversation=visible_convo)

@app.route("/transcribe", methods=["POST"])
def transcribe_audio():
    if "audio" not in request.files:
        return jsonify({"error": "No audio file"}), 400

    file = request.files["audio"]
    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(filepath)

    with open(filepath, "rb") as audio_file:
        transcript = openai.Audio.transcribe("whisper-1", audio_file)

    return jsonify({"transcript": transcript["text"]})


@app.route("/chat", methods=["GET", "POST"])
def chat_alias():
    return chat()

if __name__ == "__main__":
    app.run(debug=True)

@app.route("/export")
def export_chat():
    visible_convo = [msg for msg in conversation if msg["role"] != "system"]
    export_text = "\n".join([f"{msg['role'].capitalize()}: {msg['content']}" for msg in visible_convo])
    return export_text, 200, {
        'Content-Type': 'text/plain',
        'Content-Disposition': 'attachment; filename="chat_history.txt"'
    }

@app.route("/clear", methods=["POST"])
def clear_chat():
    
    if "username" not in session:
        return redirect("/login")

    username = session["username"]
    if "convos" not in session:
        session["convos"] = {}
    if username not in session["convos"]:
        session["convos"][username] = []
    conversation = session["convos"][username]
    
    conversation = []
    return '', 204

from flask import session, redirect

app.secret_key = os.getenv("FLASK_SECRET_KEY", "mysecretkey")
users = {}

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        users[username] = password
        session["username"] = username
        return redirect("/")
    return render_template("signup.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        if users.get(username) == password:
            session["username"] = username
            return redirect("/")
        return "Invalid login", 403
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.pop("username", None)
    return redirect("/login")
@app.route("/transcribe", methods=["POST"])
def transcribe():
    audio = request.files["audio"]
    audio.save("temp.webm")
    audio_file = open("temp.webm", "rb")
    transcript = openai.Audio.transcribe("whisper-1", audio_file)
    return jsonify({"text": transcript["text"]})
